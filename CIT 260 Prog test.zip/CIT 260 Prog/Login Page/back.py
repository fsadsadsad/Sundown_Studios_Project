User = input()
Pass = input()